// 点击工具栏图标：弹出独立迷你窗（第一方上下文，登录态正常）
// 尺寸 = iPhone Pro Max 逻辑分辨率 440 x 956 pt（20.5:9 竖屏）
// 屏幕不够高时按比例收窄，保持 iPhone 比例完整显示
/* global chrome */
const TARGET_W = 440;
const TARGET_H = 956;

chrome.action.onClicked.addListener(async () => {
    const HMargin = 80; // 预留系统菜单栏 / 任务栏 / Dock 余量
    let [w, h] = [TARGET_W, TARGET_H];

    try {
        const [display] = await chrome.system.display.getInfo();
        const workArea = display.workArea; // 已扣除系统栏的可用区域
        const availH = workArea.height - HMargin;
        if (h > availH) {
            // 等比缩小，保持 440:956 比例
            w = Math.round(TARGET_W * (availH / TARGET_H));
            h = Math.round(availH);
        }
    } catch (_e) {
        // 读不到屏幕信息就用目标尺寸，由系统自行钳制
    }

    chrome.windows.create({
        url: "https://edge.vuejs-core.cn",
        type: "popup",
        width: w,
        height: h,
        focused: true,
    });
});
